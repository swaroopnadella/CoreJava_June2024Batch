package day2;

public enum TestEnum {

}
