package day2;

public class TestClass2 {

}
