package day2;

public class PrimitiveDataTypeInteger {

	public static void main(String[] args) {
		
		int a; //declaration
		a=100; // assignment / defined
		
		int p;
		p=a; // usage
		
		System.out.println(a); // usage of values
		System.out.println(p);
		
		int b=200; // declaration and assignment
		System.out.println(b);
		
		//Multiple variables
		
		//int c,d,e,f,g;
		int c;
		int d;
		int e;
		c=1;
		d=2;
		e=3;
		System.out.println(c+" "+d+" "+e);
		
		//Multiple variables creation and assign values
		int x=20,y=30,z=50;
		
		System.out.println(x+"  "+y+"  "+z);
		System.out.println(x);
		System.out.println(y);
		System.out.println(z);
		
		
		
		
		
		
	}

}
