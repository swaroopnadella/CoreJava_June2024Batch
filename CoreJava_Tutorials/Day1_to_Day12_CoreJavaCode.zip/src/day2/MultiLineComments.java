package day2;

public class MultiLineComments {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//This is just for testing multi line comments
		// Author: Swaroop Nadella
		// Login page validation
		
		
		  System.out.println("Line - One"); System.out.println("Line - Two");
		  System.out.println("Line - Three");
		  
		  System.out.println("Line - Four"); System.out.println("Line - Five");
		 
		
	}

}
