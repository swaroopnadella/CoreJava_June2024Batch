package day4;

public class LogicalOperators {

	public static void main(String[] args) {
		
		// Logical Operators   &&  ||  !
		
		// LOGICAL AND a&&b
		/*
		boolean a=true;
		boolean b=true;
		
		boolean  bool = a&&b;  // LOGICAL AND
		System.out.println(bool);
		*/
		
		// LOGICAL OR
		/*
		boolean a=false;
		boolean b=false;
		
		boolean  bool = a||b;  // LOGICAL OR
		System.out.println(bool);  */
		
		// LOGICAL NOT  !A
		
		boolean a = false;
		boolean result = !a;
		
		System.out.println(result);
		
		
		
		
		
	}

}
