package day10;

import java.util.Arrays;

public class ArraysStringExample {
	
	
	public static void main(String[] args) {
		String s[] = {"Java","Python","CPLUSPLUS","JavaScript","TypeScript"};
		
		//System.out.println(Arrays.toString(s));
		String str = Arrays.toString(s);
		System.out.println(str);
	}
	
}
