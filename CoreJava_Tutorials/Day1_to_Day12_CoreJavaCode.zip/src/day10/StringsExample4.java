package day10;

public class StringsExample4 {

	public static void main(String[] args) {
		
		//replace()
		//single or multiple characters it will replace in a String
		
		String str = "JavaProgrammingPractice";
		System.out.println(str.replace('a', 'b'));;
		System.out.println(str.replace('c', 'D'));;
		
		String str1 = "Selenium Java Selenium Python Selenium JS";
		System.out.println(str1);
		System.out.println(str1.replace("Selenium", "Playwright"));
		
		
	}

}
