package day3;

public class DataType2 {

	public static void main(String[] args) {
		
		//Different approaches to create variables
		
		//Approach1 - same or different datatypes
		int a; // declaration
		a=10; // assignment
		float b;
		b=20.00f;
		
		//Approach2 - same data types
		int a1,b1; // multiple variable declaration
		a1=50; // asignment
		b1=60; // assignment
		
		//Approach3 - same data type
		int a2=30,b2=60; // multiple variable declaration and assignment
		
		
		
		
		
		
	}

}
