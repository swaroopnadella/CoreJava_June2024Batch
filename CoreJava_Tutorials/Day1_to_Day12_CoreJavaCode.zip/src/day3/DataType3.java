package day3;

public class DataType3 {

	public static void main(String[] args) {
		
		int a=10,b=20;
		
		System.out.println(a+b);
		System.out.println(a+b+"test123456");
		System.out.println("test"+a+b+"test123456");
		
		System.out.println("Value of a: "+a); // Concatenation 1020
		System.out.println();
		
		System.out.println("test"+(a+b)+"add"); //test30add
		
		
	}

}
