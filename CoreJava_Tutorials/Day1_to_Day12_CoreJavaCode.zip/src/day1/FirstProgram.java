package day1;

public class FirstProgram {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		System.out.println("Welcome to Core Java");
		System.out.println("My name is Swaroop");
	}
	
}


