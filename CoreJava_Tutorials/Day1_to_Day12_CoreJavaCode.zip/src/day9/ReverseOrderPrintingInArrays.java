package day9;

public class ReverseOrderPrintingInArrays {

	public static void main(String[] args) {
		
		int arr[]= {66,33,22,11,10,55,60,40,70,99};
		
		//Print Reverse order
		
		//Normal for loop
		
		for(int i=arr.length-1;i>=0;i--) {
			
			System.out.println(arr[i]);
			
		}
		
		

	}

}
