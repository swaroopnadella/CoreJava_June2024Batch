package day5;

public class CheckingPositiveNegative {

	public static void main(String[] args) {
		
		//Number
		int num = 0;
		if(num>0) {
			System.out.println("Positive Number");
		}
		else if(num<0) {
			System.out.println("Negative Number");
		}
		else {
			System.out.println("Number is Zero");
		}
		
		System.out.println("After the if else ladder");
	}

}
