package day5;

public class NestedIfElse {

	public static void main(String[] args) {
		
		// nested if else
		if(true) {
			if(false) {
				System.out.println("First Statement");
			}
			else
				System.out.println("Second statement");
		}
		else
		{
			System.out.println("Third statement");
		}
		
		
	}

}
