package day5;

public class IfElseConditionExample2 {

	public static void main(String[] args) {
		
		int marks = 25;
		if(marks>=50) {
			System.out.println("Qualified for the admission: "+marks);
		}
		else {
			System.out.println("Not Qualified for the admission: "+marks);
		}
		
		System.out.println("After if block");
		
	}

}
