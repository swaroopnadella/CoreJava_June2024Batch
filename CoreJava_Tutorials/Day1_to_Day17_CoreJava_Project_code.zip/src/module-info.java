/**
 * 
 */
/**
 * 
 */
module CoreJava_Tutorials {
	requires org.apache.commons.lang3;
}