package day17;

public class Test1 {

	static String str = "Swaroop";
	
	
	public static void main(String[] aaa) {
		
		System.out.println(Test1.str.length());
		
		System.out.print(1);
		System.out.println("Swaroop");
		
		Math.random();
		
	}

}
