package day13;

public class StringIndexOf {

	public static void main(String[] args) {
		
		String str = "Swaroop";
		
		int index = str.indexOf('Z');
		System.out.println(index);
		
	}

}
