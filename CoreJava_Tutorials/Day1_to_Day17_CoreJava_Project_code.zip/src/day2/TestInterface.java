package day2;

public interface TestInterface {

}
