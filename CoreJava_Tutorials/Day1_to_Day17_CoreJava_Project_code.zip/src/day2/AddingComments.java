package day2;

public class AddingComments {

	public static void main(String[] args) {
		
		//System.out.println("This is for learning comments - Line 1");
		
		System.out.println("This is for learning comments - Line 2");
		
		System.out.println("This is for learning comments - Line 3");
		
		
	}

}
