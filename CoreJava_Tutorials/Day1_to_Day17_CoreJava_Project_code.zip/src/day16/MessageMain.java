package day16;

public class MessageMain {

	public static void main(String[] args) {
		
		Message msg = new Message(); //no inputs
		//no need to write explicit method call
		
		Message msg1 = new Message("Swaroop");
		
		Message msg2 = new Message("Swaroop","Nadella");
	}

}
