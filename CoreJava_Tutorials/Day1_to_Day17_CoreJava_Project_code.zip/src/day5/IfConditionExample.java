package day5;

public class IfConditionExample {

	public static void main(String[] args) {
		
		int marks = 45;
		if(marks>50) {
			System.out.println("Qualified for the admission: "+marks);
		}
		System.out.println("After if block");
		
	}

}
