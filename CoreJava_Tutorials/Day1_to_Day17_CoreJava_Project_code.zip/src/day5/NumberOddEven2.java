package day5;

public class NumberOddEven2 {

	public static void main(String[] args) {
		
		// Number - Even or Odd
		
		int num = 33; // assignment
		if(num%2 != 0)  // == comparision
		{
			System.out.println("Odd Number");
		}
		else
			System.out.println("Even Number");
		
	}

}
