package day5;

public class IfElseExampleWithBoolean {

	public static void main(String[] args) {
		
		/*
		boolean bool = false;
		if(bool) {
			System.out.println("First Statement");
		}
		else
		{
			System.out.println("Second statement");
		}  */
		
		boolean bool = 1==2;
		if(bool) {
			System.out.println("If block");
		}
		else {
			System.out.println("else block");
		}
		
		
		
	}

}
