package day12;

public class Test1 {

	public static void main(String[] args) {
		
		String str = "Swaroop";
		
		System.out.println(str.indexOf('#'));

	}

}
