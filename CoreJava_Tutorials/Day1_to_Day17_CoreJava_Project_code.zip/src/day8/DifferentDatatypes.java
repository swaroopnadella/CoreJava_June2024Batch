package day8;

public class DifferentDatatypes {

	public static void main(String[] args) {
		
		Object obj[]= {250,45.21,'S',"WELCOME",true};
		
		
		
	}

}
