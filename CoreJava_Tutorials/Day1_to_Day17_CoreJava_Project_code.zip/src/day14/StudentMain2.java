package day14;

public class StudentMain2 {

	public static void main(String[] args) {
		
		//Object created, but no reference given on left side
		new Student().displayAllValues();
		

	}

}
