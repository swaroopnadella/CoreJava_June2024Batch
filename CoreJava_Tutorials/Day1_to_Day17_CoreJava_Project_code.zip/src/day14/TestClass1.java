package day14;

public class TestClass1 {
	
	public static void main(String[] args) {
		new Student().name = "Sandip k"; //object1
		new Student().rollnum = 101; //object2
		new Student().address = "Gujarat"; //object3
		new Student().displayAllValues(); //object4


	
	}

}
