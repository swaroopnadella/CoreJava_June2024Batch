package day3;

public class DataTypeVar {

	public static void main(String[] args) {
		
		// Java 10 - JDK 10
		
		var variable1 = 10;
		variable1 = 20;
		System.out.println(variable1);
		
		var v1 = 23.45;
		System.out.println(v1);
		
		var v2="Swaroop";
		System.out.println(v2);
		
		var v3='R';
		System.out.println(v3);
		
		
		
		
		
	}

}
