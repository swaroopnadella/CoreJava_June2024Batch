package day3;

public class PrimitiveDataTypes {

	public static void main(String[] args) {
		
		//byte/short/int/long - reserved keywords
		
		byte b; // declaration
		b = 100; // assignment / defined
		System.out.println(b); //usage
		
			
		byte by = 12;
		System.out.println(by);
		
		short sh=34;
		System.out.println(sh);
		int in = 456;
		System.out.println(in);
		long l = 56789;
		System.out.println(l);
		
		long x = 123456789012345L;
		System.out.println(x);
		
		//float/double
		
		float f = 123.45F;
		System.out.println(f);
		
		double d = 456.789;
		System.out.println(d);	
		
		//char
		char c = 'D';
		System.out.println(c);
		
		char ch = 'A';
		System.out.println(ch);
			
		//boolean - true / false
		
		boolean bl = false;
		System.out.println(bl);
		
		boolean bool = true;
		System.out.println(bool);
		
		
		
		
		
		
		
		
	}

}
