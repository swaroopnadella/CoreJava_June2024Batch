package day4;

public class AssignmentOperator {

	public static void main(String[] args) {
		
		// Assignment Operators   = += -= *= /= %=
		/*
		int a=10; // assignment
		System.out.println(a);
		a=20; // updating the value
		System.out.println(a);
		a=30;
		System.out.println(a);
		a=500;
		System.out.println(a); */
		
		// +=
		
		int b = 1000;
		b+=100;    //b = b + 100; - shortform
		System.out.println(b); // 1100
		
		//-=
		
		int c = 1000;
		c-=100;    //c = c - 100; - shortform
		System.out.println(c); //900
		
		//*=
		int d = 1000;
		d*=100;    //d = d * 100;  shortform
		System.out.println(d); //100,000
		
		//   /=
		int e = 1000;
		e/=100;    //e = e / 100;  shortform
		System.out.println(e); //10
		
		// % =
		int f = 1000;
		f%=100;    //f = f % 100; - shortform
		System.out.println(f); //0
		
		
		
		
	}

}
