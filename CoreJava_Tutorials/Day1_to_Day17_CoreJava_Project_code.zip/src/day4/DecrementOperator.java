package day4;

public class DecrementOperator {

	public static void main(String[] args) {
		
		//Decrement Operator --
		
		/* //Example 1
		int a = 10;
		a--;   //a=a-1; //10-1
		System.out.println(a); */
		
		/*
		//Example 2
		int a = 100;
		int result = a--; // Post decrement operation
		System.out.println(result);
		System.out.println(a); */
		
		//example 3
		int a = 200;
		int result = --a; // Pre decrement operation
		System.out.println(result);
		System.out.println(a);
	}

}
