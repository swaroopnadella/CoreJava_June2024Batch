package day4;

public class RelationalOperators {

	public static void main(String[] args) {
		
		//Relational Operators  > >= < <= != ==
		
		// Output will be an Boolean value - true/false

		/* Greater than
		int a=10;
		int b=20;
		boolean bool = a>b;
		System.out.println(bool); */
		
		/* Greater than or equal to
		int a=10;
		int b=20;
		boolean bool = a>=b;
		System.out.println(bool); */
		
		/*
		//Less than <
		int a=10;
		int b=20;
		boolean bool = a<b;
		System.out.println(bool); */
		
		/*
		// Less than or equal to
		int a=30;
		int b=40;
		boolean bool = a<=b;
		System.out.println(bool); */
		
		/*
		// Not equal to
		int a=20;
		int b=20;
		boolean bool = a!=b;
		System.out.println(bool); */
		
		// == Comparision operation
		int a=10;
		int b=10;
		boolean bool = a==b;
		System.out.println(bool);
		
		
		
		
		
		
		
	}

}
