package day4;

public class ArthimeticOperators {

	public static void main(String[] args) {
		
		//Arthimetic Operators
		// + - * / %
		
		/* Addition
		int a = 50;
		int b = 25;
		int result = a+b;
		System.out.println(result);
	*/
		/* Substraction
		int a=30;
		int b=10;
		int result = a-b;
		System.out.println(result);
		
	*/ 
		/* Multiplication
		int a=30;
		int b=10;
		int result = a*b;
		System.out.println(result); */
		
		//Division
		/* a=30;
		int b=10;
		int result = a/b;
		System.out.println(result) */
		
		// Remainder - % - Module operator
		int a=55;
		int b=5;
		int result = a%b;
		System.out.println(result);
		
		
	}

}
