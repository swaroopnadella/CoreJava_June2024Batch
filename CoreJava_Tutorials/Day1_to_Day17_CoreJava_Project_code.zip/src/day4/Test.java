package day4;

public class Test {

	
	public static void main(String[] args) {
		
		float a=15;
		float b =2;
		float c=a/b;
		System.out.println(c);
		
		
		
	}
	
	
	
	
}
