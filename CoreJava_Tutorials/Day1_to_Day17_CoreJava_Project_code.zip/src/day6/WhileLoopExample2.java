package day6;

public class WhileLoopExample2 {

	public static void main(String[] args) {
		
		// print values from 10 to 1 - descending order
		
		int i=10; //Initialization
		while(i>=1) { //condition
			System.out.println(i);
			i--; //decrement
		}
		System.out.println("After While loop");
		
	}

}
