package day6;

public class DoWhileExample {

	public static void main(String[] args) {
		
		//Example 1: Print 1 to 10 numbers
		/*
		int i=1; // Initialization
		do
		{
			System.out.println(i); //statements
			i++; // increment
		}while(i<=10); //condition
		*/
		
		// Example 2: Print 10 to 1 numbers
		int j=10;
		do
		{
			System.out.println(j);
			j--;
		}while(j>=1);
	}

}
